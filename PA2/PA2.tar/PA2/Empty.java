import meggy.Meggy;

class Empty {
       public static void main(String[] test){

        }
}
