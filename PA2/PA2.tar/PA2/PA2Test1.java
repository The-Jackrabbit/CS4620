import meggy.Meggy;

class PA2Test1 {
       public static void main(String[] test){
               Meggy.setPixel( (byte)7, (byte)7, Meggy.Color.VIOLET );
        }
}
