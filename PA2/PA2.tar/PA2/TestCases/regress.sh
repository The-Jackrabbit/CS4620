#!/bin/bash

# usage: 
#   ./regress.sh

for filename in `ls *.in`
do
    echo "Regression testing MJPA2.jar $filename"

    # run the input file with the MJPA2 compiler
	if [[ $filename == "err"* ]]; then
   		java -jar ../MJPA2.jar $filename &> t
	else
		java -jar ../MJPA2.jar $filename > t
	fi

    diff t $filename.OK
    echo "DONE with MJPA2.jar $filename"
    echo "============================="
	rm -f t
done


