Test files are names spec.in for special, resrvwd.in and resrvphrs.in for reserved words & reserved 
phrases respectively, intlit.in for integer literals, id.in for id's, and cmnt.in for comments.
The error versions of these files are named err[original file name].in (example: resrvwd.in -> errresrvwd.in)
