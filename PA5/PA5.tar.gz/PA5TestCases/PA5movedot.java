/**
 * PA5movedot.java
 * 
 * Local vars keep track of where dot is so can move it around with DPad.  
 * Also have a local var that stores a tone value and then uses that 
 * to call toneStart when a button is pressed.
 * 
 * MMS, 2/2/11
 */

import meggy.Meggy;

class PA5movedot {

    public static void main(String[] whatever){
        
    }
}

class Dot {
    byte curr_x;
    byte curr_y;
    Meggy.Color dotcolor;
    

}
