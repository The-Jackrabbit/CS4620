Test files are located in the PA4TestCases directory. Doubly defined methods, variables, and classes are tested.
Undefined methods, variables, and classes are tested. Type check errors on method signatures and return types are tested.
Complex valid programs are tested.

