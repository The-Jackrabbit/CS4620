Test files are located in the PA5TestCases directory. Doubly declared variables are tested.
Undeclared variables are tested. Type check errors classes are tested.
Complex valid programs are tested.

