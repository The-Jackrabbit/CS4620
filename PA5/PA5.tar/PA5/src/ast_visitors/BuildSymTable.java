package ast_visitors;

import ast.node.*;
import ast.visitor.DepthFirstVisitor;
import java.util.*;

import symtable.*;
import exceptions.InternalException;
import exceptions.SemanticException;

public class BuildSymTable extends DepthFirstVisitor
{
    
	private SymTable CurrentST;
	static int offsetY = 1; //offset variables in current method
	static int offsetZ = 0; //offset variables in current class
	static String currentClass = null; //name of current class
   
	public BuildSymTable() {
   		CurrentST = new SymTable();
	}

	public SymTable getSymTable() {
		return CurrentST;
	}

	public void inTopClassDecl(TopClassDecl node)
    {
		//check for doubly-defined class
		if(CurrentST.lookupCurrent(node.getName()) != null)
			throw new SemanticException("Doubly Defined Class", node.getLine(), node.getPos());
 		//otherwise add new ClassSTE to current scope
		ClassSTE Class = new ClassSTE(node.getName());
        CurrentST.insert(Class);
		CurrentST.enterScope(node.getName());
		currentClass = node.getName();
    }

    public void outTopClassDecl(TopClassDecl node)
    {
		((ClassSTE) CurrentST.getCurrentScope()).setClassSize(offsetZ);
        CurrentST.exitScope();
		currentClass = null;
		offsetZ = 0;
    }

	public void inMethodDecl(MethodDecl node)
    {		
		//check for doubly-defined method
		if(CurrentST.lookupCurrent(node.getName()) != null)
			throw new SemanticException("Doubly Defined Method", node.getLine(), node.getPos());
		//otherwise add new MethodSTE to current scope
		MethodSTE Method = new MethodSTE(node.getName(), new Type.Signature(node.getType(), node.getFormals()));
		CurrentST.insert(Method);
		CurrentST.enterScope(node.getName());
		//add implied "this" VarSTE
		Type varType = new Type.Class(currentClass);
        VarSTE Formal = new VarSTE("this", varType, 'Y', offsetY);
		CurrentST.insert(Formal);
		offsetY += varType.getAVRTypeSize();
    }

    public void outMethodDecl(MethodDecl node)
    {
		offsetY = 1;
        CurrentST.exitScope();
    }

	public void inFormal(Formal node)
    {
		//check for doubly-defined variable
		if(CurrentST.lookupCurrent(node.getName()) != null)
			throw new SemanticException("Doubly Defined Variable", node.getLine(), node.getPos());
		//otherwise, add new VarSTE to current scope
		Type varType = CurrentST.getType(node.getType());
        VarSTE Formal = new VarSTE(node.getName(), varType, 'Y', offsetY);
		CurrentST.insert(Formal);
		offsetY += varType.getAVRTypeSize(); 
    }

	public void inVarDecl(VarDecl node)
    {		
		//check for doubly-defined variable
		if(CurrentST.lookup(node.getName()) != null)
			throw new SemanticException("Doubly Defined Variable", node.getLine(), node.getPos());
		//otherwise add new VarSTE to current scope
		Type varType = CurrentST.getType(node.getType());
		//variable can be either in a class or a method. Check if current scope is for class
		VarSTE Var;
		if(CurrentST.getCurrentScope() instanceof ClassSTE) {
			Var = new VarSTE(node.getName(), varType, 'Z', offsetZ);
			offsetZ += varType.getAVRTypeSize();
		} else {
			Var = new VarSTE(node.getName(), varType, 'Y', offsetY);
			offsetY += varType.getAVRTypeSize();
		}		
		CurrentST.insert(Var);
    }
}
