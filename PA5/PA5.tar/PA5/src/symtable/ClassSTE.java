package symtable;
import java.util.*;

public class ClassSTE extends STE {
	int class_Size;
	
	public ClassSTE(String Name) {
		super(Name, new Scope());
		class_Size = 0;
	}

	public int getClassSize() {
		return this.class_Size;
	}

	public void setClassSize(int class_Size) {
		this.class_Size = class_Size;
	}
}
