package symtable;
import java.util.*;

public class ClassSTE extends STE {
	
	public ClassSTE(String Name) {
		super(Name, new Scope());
	}
}
