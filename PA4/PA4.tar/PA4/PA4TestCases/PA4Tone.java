/**
 * PA4raindrop.java
 * 
 * A blue pixel falls from top to bottom of the screen over and over in an
 * infinite loop.
 *   
 * MMS, 2/2/11
 */

import meggy.Meggy;

class PA4Tone {

    public static void main(String[] whatever){
        Meggy.toneStart(Meggy.Tone.Cs3, 100);
    }
}
