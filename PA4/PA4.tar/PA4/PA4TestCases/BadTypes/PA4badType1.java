/**
 * PA4nodef.java
 * 
 * call undefined method
 *   
 * WB, 3/12
 */

import meggy.Meggy;

class PA4badType1 {

    public static void main(String[] whatever){
	new C().setP(Meggy.Color.RED,(byte)7,Meggy.Color.BLUE);
    }
}

class C {
    
    public void setP(byte x, byte y, Meggy.Color c) {
            Meggy.setPixel(x, y, c);    
    }
    
}
